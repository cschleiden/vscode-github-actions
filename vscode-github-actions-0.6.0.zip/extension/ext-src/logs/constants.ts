export const LogScheme = "gh-actions";
