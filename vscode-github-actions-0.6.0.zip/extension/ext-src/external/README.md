Code in here is forked from the Microsoft GitHub Pull Request extension
https://github.com/microsoft/vscode-pull-request-github/