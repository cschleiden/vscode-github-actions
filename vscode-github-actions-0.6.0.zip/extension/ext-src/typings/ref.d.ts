/// <reference path='./git.d.ts'/>

declare module "tunnel";
declare module "ssh-config";

declare module "tweetsodium";
declare module "atob";
declare module "btoa";
declare module "util";
