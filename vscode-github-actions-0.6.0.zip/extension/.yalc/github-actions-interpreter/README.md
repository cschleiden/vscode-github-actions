# `github-actions-interpreter`

> TODO: description

## Usage

```
const githubActionsInterpreter = require('github-actions-interpreter');

// TODO: DEMONSTRATE API
```
